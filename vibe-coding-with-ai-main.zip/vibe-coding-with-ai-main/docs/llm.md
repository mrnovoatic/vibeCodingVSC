
Informal candid tone.
