

Y Combinator on how to get the most of vibe coding
https://x.com/benln/status/1918302622630478120


## UI/UX Prototiping

- v0
- Hero UI
- Figma ([Read about building with AI and Figma](https://www.figma.com/ai/our-approach/))

## End to End Coding Generation

- Replit
- Lovable
- Bolt
- Devin
- Codex by OpenAI

## Developer Augmentation

- Windsurf
- Cursor
- VSCode with Github Copilot

Other smaller tools for augmentation

- GoCodeo


## Libraries

- [SaaS Builder](https://github.com/jatingarg619/saas-builder): AI-native SaaS framework that builds full-stack apps using autonomous AI agents