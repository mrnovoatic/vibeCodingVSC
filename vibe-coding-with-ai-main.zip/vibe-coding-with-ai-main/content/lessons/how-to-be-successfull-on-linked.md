

- [ ] Fix your bio: What you offer others and what are, you building or going
- [ ] Join communities and groups: [Vibe Coding](https://www.linkedin.com/search/results/groups/?keywords=vibe%20coding&origin=SWITCH_SEARCH_VERTICAL&sid=%2C(0)