
I want you to make the most out of this course, not only learning technical vibe coding stuff but becoming a successful vibe coder. Please read carefully the following list an try completing all the tasks because Iwe think every single one of them matters a lot.

I will do my best to justify and convince you to do each of them, and I can only hope you have some faith in my method!

## Get prepared to learn in public

At 4Geeks everythign you learn we will strongly encourage you to do it very publicly, here is why: [Why learning in public](https://4geeks.com/lesson/learn-in-public)

- [ ] Have your linkedin ready and join the [vibe coding groups](https://www.linkedin.com/search/results/groups/?keywords=vibe%20coding&origin=SWITCH_SEARCH_VERTICAL&sid=Fnl).
- [ ] Have your twitter ready and join the [vibe coding communities](https://x.com/i/communities/suggested?q=vibe%20coding).
- [ ] 👉 Join the [4Geeks Twitter Community](https://x.com/i/communities/1922475612318364120) and say hello! At 4Geeks we support each other in our learning!
- [ ] 👉 Follow me on X [@alesanchezr](https://x.com/alesanchezr) and lets build together!

## Download the tools

We are going to be building using Cursor, Windsurf and HeroUI.Chat, take some time to download them and ask on the whatsapp community for your cupon codes that will give you discounts on each of these products.

- [ ] [Download Windsurf](https://windsurf.com/) and create your account
- [ ] [Download Cursor](https://www.cursor.com/) and crate your account
- [ ] Create create your account on [HeroUI Chat](https://heroui.chat/)

## Coding preparation

- [ ] Make you to read this coding preparation and follow it through and through.